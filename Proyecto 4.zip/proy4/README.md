# Proyecto 1 de VisionArtificial

#Autores
#Guillermo Mena Juez
#Alberto Ricci Vázquez

